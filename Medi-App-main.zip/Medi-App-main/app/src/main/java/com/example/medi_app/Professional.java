package com.example.medi_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Professional extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pofessional);
    }
}
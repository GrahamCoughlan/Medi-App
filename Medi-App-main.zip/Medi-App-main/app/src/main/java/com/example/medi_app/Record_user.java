package com.example.medi_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Record_user extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.record_user_info);
    }
}